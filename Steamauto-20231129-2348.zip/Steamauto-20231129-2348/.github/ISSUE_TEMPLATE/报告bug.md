---
name: 报告bug
about: 反馈程序运行bug
title: ''
labels: 程序问题
assignees: ''

---

请注意：不接受“闪退”类反馈，所有“闪退”类反馈一律会被关闭
请将程序在cmd或者powershell中运行，程序所谓的“闪退”之前一定会有报错，请提供报错，否则我们无法解决问题。
同时，请提供logs目录内最新的日志！
